import { Prisma } from "@prisma/client";
import type { ProblemFiltersDto } from "../dto/problemFilters.dto";

export function buildProblemWhere(
  userId: string,
  filters: ProblemFiltersDto
): Prisma.ProblemWhereInput {

  const where: Prisma.ProblemWhereInput = {
    userId,
  };
  // search
    if (filters.search?.trim()) {

    where.OR = [

        {
        title: {
            contains: filters.search,
            mode: "insensitive",
        },
        },

        {
        problemNumber: {
            contains: filters.search,
            mode: "insensitive",
        },
        },

        {
        slug: {
            contains: filters.search,
            mode: "insensitive",
        },
        },

    ];

    }


    // difficulty
    if (filters.difficulty?.length) {

    where.difficulty = {

        in: filters.difficulty,

    };

    }


    // /platform
    if (filters.platform?.length) {

    where.platform = {

        in: filters.platform,

    };

    }


    // status
    if (filters.solved!==undefined) {

    where.solved = filters.solved

    }


    // topics
    if (filters.topics?.length) {

    where.topics = {

        some: {

        topic: {

            name: {

            in: filters.topics,

            },

        },

        },

    };

    }





    // solverDate
    if (

    filters.solvedAfter ||

    filters.solvedBefore

    ) {

    where.updatedAt = {};

    if (filters.solvedAfter) {

        where.updatedAt.gte =
        new Date(filters.solvedAfter);

    }

    if (filters.solvedBefore) {

        where.updatedAt.lte =
        new Date(filters.solvedBefore);

    }

    }

  return where;
}

