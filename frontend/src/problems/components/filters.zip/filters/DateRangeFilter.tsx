import { Calendar } from "lucide-react";

interface DateRangeFilterProps {
  fromDate?: string;
  toDate?: string;
  onFromChange: (value: string | undefined) => void;
  onToChange: (value: string | undefined) => void;
}

export default function DateRangeFilter({
  fromDate,
  toDate,
  onFromChange,
  onToChange,
}: DateRangeFilterProps) {
  const hasValue = !!fromDate || !!toDate;

  return (
    <div
      className={`flex h-9 items-center gap-1 rounded-full border px-1 ${
        hasValue ? "border-ring bg-accent" : "border-border bg-background"
      }`}
    >
      <Calendar
        className={`ml-2 h-4 w-4 ${
          hasValue ? "text-accent-foreground" : "text-muted-foreground"
        }`}
      />
      <input
        type="date"
        value={fromDate ?? ""}
        onChange={(e) =>
          onFromChange(e.target.value || undefined)
        }
        className="h-full w-[130px] bg-transparent px-1.5 text-sm outline-none [color-scheme:light] dark:[color-scheme:dark]"
        placeholder="From"
      />
      <span className="text-muted-foreground">-</span>
      <input
        type="date"
        value={toDate ?? ""}
        onChange={(e) =>
          onToChange(e.target.value || undefined)
        }
        className="h-full w-[130px] bg-transparent px-1.5 text-sm outline-none [color-scheme:light] dark:[color-scheme:dark]"
        placeholder="To"
      />
    </div>
  );
}
