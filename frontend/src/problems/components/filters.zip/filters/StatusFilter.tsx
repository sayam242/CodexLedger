interface StatusFilterProps {
  value?: boolean;
  onChange: (value: boolean | undefined) => void;
}

const OPTIONS = [
  { label: "All", value: undefined },
  { label: "Solved", value: true as const },
  { label: "Unsolved", value: false as const },
] as const;

export default function StatusFilter({ value, onChange }: StatusFilterProps) {
  return (
    <div className="flex h-9 items-center overflow-hidden rounded-full border border-border bg-background">
      {OPTIONS.map((opt) => {
        const isActive = value === opt.value;
        return (
          <button
            key={opt.label}
            onClick={() => onChange(opt.value)}
            className={`px-3.5 text-sm transition-all ${
              isActive
                ? "bg-primary font-medium text-primary-foreground"
                : "text-muted-foreground hover:text-foreground"
            }`}
          >
            {opt.label}
          </button>
        );
      })}
    </div>
  );
}
